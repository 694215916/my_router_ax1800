/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2010. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <pthread.h>
#include <signal.h>
#include <string.h>
//#include <cutils/properties.h>

//#include "bt_em.h"
#include "bt_drv.h"
#include "bt_relayer.h"

#define LOG_TAG           "BT_RELAYER "
//#include <cutils/log.h>

#if (ETHERNET_SUPPORT)
#include <sys/socket.h>
#include <sys/ioctl.h> /* sock ioctl */
#include <sys/select.h>
#include <net/if.h>    /* ifreq */
#include <net/ethernet.h> /* sockaddr_ll */
#include <netinet/in.h>
#include <netpacket/packet.h>
//#include <linux/if_arp.h>

#define PKT_BUF_SIZE 1600 /*Size of Packet Buffer for packets from host*/
#ifndef IFNAMSIZ
#define IFNAMSIZ 16
#endif
#endif /* ETHERNET_SUPPORT */

/**************************************************************************
 *                  G L O B A L   V A R I A B L E S                       *
***************************************************************************/

static int serial_fd = -1;
static int bt_fd = -1;
static BOOL bt_power_on_cmd = FALSE;
static pthread_t txThread; // PC->BT moniter thread
static pthread_t rxThread; // BT->PC moniter thread

/**************************************************************************
 *                          F U N C T I O N S                             *
***************************************************************************/

void dump_hex(unsigned char *buf, int dump_len)
{
	int i;

	printf("dump_packet");
	for (i=0; i < dump_len; i++){
		if(!(i % 0x10))
			printf("\n%08x:", i);
		if(!(i % 4))
			printf("  ");
		printf("%02x ", buf[i]);
 	}

	printf("\n\n");
}

static int uart_speed(int s)
{
    switch (s) {
    case 9600:
         return B9600;
    case 19200:
         return B19200;
    case 38400:
         return B38400;
    case 57600:
         return B57600;
    case 115200:
         return B115200;
    case 230400:
         return B230400;
    case 460800:
         return B460800;
    case 500000:
         return B500000;
    case 576000:
         return B576000;
    case 921600:
         return B921600;
    default:
         return B57600;
    }
}

/* Initialize serial port to PC */
int init_serial(int port, int speed)
{
    struct termios ti;
    int fd;
    int baudenum;
    char dev[20] = {0};
//    char usb_prop[PROPERTY_VALUE_MAX];

    if (port < 4){ //serial port UART
        sprintf(dev, "%s%d", SERIAL_DEVICE_NAME, port);
    }
    else{ //serial port USB
        sprintf(dev, "/dev/ttyGS2");
    }

    fd = open(dev, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (fd < 0) {
        ERR("Can't open serial port %s\n", dev);
        return -1;
    }

    tcflush(fd, TCIOFLUSH);

    if (tcgetattr(fd, &ti) < 0) {
        ERR("Can't get serial port setting\n");
        close(fd);
        return -1;
    }

    cfmakeraw(&ti);

    if (port < 4){ //serial port UART
        ti.c_cflag |= CLOCAL;
        ti.c_lflag = 0;

        ti.c_cflag &= ~CRTSCTS;
        ti.c_iflag &= ~(IXON | IXOFF | IXANY);

        /* Set baudrate */
        baudenum = uart_speed(speed);
        if ((baudenum == B57600) && (speed != 57600)) {
            ERR("Serial port baudrate not supported!\n");
            close(fd);
            return -1;
        }

        cfsetospeed(&ti, baudenum);
        cfsetispeed(&ti, baudenum);
    }
#if defined(RELAYER_USB_SUPPORT)
    else{ //serial port USB
        /* Set USB property to acm_third: add 1 acm port to /dev/ttyGS2 */
        property_get("sys.usb.config", usb_prop, NULL);
        if(0 != strcmp(usb_prop, "acm_third")){
            if(property_set("sys.usb.config", "acm_third") < 0){
                ERR("Can't set USB property to open a VCOM\n");
                close(fd);
                return -1;
            }
            else{
                DBG("Set USB property to open a VCOM\n");
            }
        }
    }
#else
	else {
		ERR("Unknown UART port #\n");
	}
#endif

    if (tcsetattr(fd, TCSANOW, &ti) < 0) {
        ERR("Can't set serial port setting\n");
        close(fd);
        return -1;
    }

    tcflush(fd, TCIOFLUSH);

    return fd;
}

#if (UART_SUPPORT)
static
int write_data_to_pc(int fd, unsigned char *buffer, unsigned long len)
{
    int bytesWritten = 0;
    int bytesToWrite = len;

    if (fd < 0)
        return -1;

    // Send len bytes data in buffer
    while (bytesToWrite > 0){
        bytesWritten = write(fd, buffer, bytesToWrite);
        if (bytesWritten < 0){
            if(errno == EINTR || errno == EAGAIN)
                continue;
            else
                return -1;
        }
        bytesToWrite -= bytesWritten;
        buffer += bytesWritten;
    }

    return 0;
}

static
int read_data_from_pc(int fd, unsigned char *buffer, unsigned long len)
{
    int bytesRead = 0;
    int bytesToRead = len;

    int ret = 0;
    struct timeval tv;
    fd_set readfd;

    tv.tv_sec = 5;  //SECOND
    tv.tv_usec = 0;   //USECOND
    FD_ZERO(&readfd);

    if (fd < 0)
        return -1;

    // Hope to receive len bytes
    while (bytesToRead > 0){

        FD_SET(fd, &readfd);
        ret = select(fd + 1, &readfd, NULL, NULL, &tv);

        if (ret > 0){
            bytesRead = read(fd, buffer, bytesToRead);
            if (bytesRead < 0){
                if(errno == EINTR || errno == EAGAIN)
                    continue;
                else
                    return -1;
            }
            else{
                bytesToRead -= bytesRead;
                buffer += bytesRead;
            }
        }
        else if (ret == 0){
            return -1; // read com port timeout 5000ms
        }
        else if ((ret == -1) && (errno == EINTR)){
            continue;
        }
        else{
            return -1;
        }
     }

    return 0;
}
#endif

#if (ETHERNET_SUPPORT)
static const char broadcast_addr[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
static unsigned char packet[1536];
static int sock = -1;
static unsigned char packet_send[1536];
static char my_eth_addr[6];
static int if_index;
//static char bridge_ifname[IFNAMSIZ + 1];
//static char driver_ifname[IFNAMSIZ + 1];
//static unsigned char bUnicast = FALSE;
static unsigned char eth_packet_recvd;
static unsigned int  eth_packet_len;
static unsigned int  buffer_read;
#define ETH_PORT_SIZE   (4)
static char *eth_port[ETH_PORT_SIZE] = {"br0", "eth1", "eth2", "eth3"};
unsigned short eth_protocol = 0;

static int OpenRaCfgSocket()
{
//	struct ifreq ethreq;
	struct ifreq ifr;
	struct sockaddr_ll addr;
    int i = 0;
//	struct in_addr	own_ip_addr;

	if ((sock=socket(PF_PACKET, SOCK_RAW, htons(eth_protocol))) < 0)
	{
		perror("socket");
		return -1;
	}

//#ifdef CONFIG_LAN_WAN_SUPPORT
//#if defined(CONFIG_DEFAULTS_MEDIATEK_MT7620) || defined(CONFIG_DEFAULTS_MEDIATEK_MT7628)
//	os_memcpy(ifr.ifr_name, "eth2.1" , 7);
//#else
	//TODO
    for (i = 0 ; i < ETH_PORT_SIZE ; i++) {
        os_memset(&ifr, 0, sizeof(ifr));
	    os_memcpy(ifr.ifr_name, eth_port[i], sizeof(eth_port[i]));
        DBG("ifr.ifr_name=\"%s\"\n", ifr.ifr_name);
        ioctl(sock, SIOCGIFFLAGS, &ifr);
        if (ifr.ifr_flags & IFF_UP) {
            DBG("%s is up!\n",eth_port[i]);
            break;
        }
    }
//#endif
    if (i == ETH_PORT_SIZE) {
        ERR("No ethernet interface find!!\n");
		goto close;
    }
	if (ioctl(sock, SIOCGIFINDEX, &ifr) != 0)
	{
		perror("ioctl(SIOCGIFINDEX)(eth_sock)");
		DBG("[%s]ioctl(SIOCGIFINDEX)(eth_sock)", __FUNCTION__);
		goto close;
	}

	os_memset(&addr, 0, sizeof(addr));
	addr.sll_family = AF_PACKET;
	addr.sll_ifindex = ifr.ifr_ifindex;
	if_index = ifr.ifr_ifindex;

	if (bind(sock, (struct sockaddr *) &addr, sizeof(addr)) < 0)
	{
		perror("bind");
		DBG("[%s]bind error\n", __FUNCTION__);
		goto close;
	}

	if (ioctl(sock, SIOCGIFHWADDR, &ifr) != 0)
	{
		perror("ioctl(SIOCGIFHWADDR)(eth_sock)");
		DBG("[%s]ioctl(SIOCGIFHWADDR)(eth_sock)", __FUNCTION__);
		goto close;
	}

	os_memcpy(my_eth_addr, ifr.ifr_hwaddr.sa_data, 6);

	return sock;

close:
	close(sock);
	sock = -1;
	return (-1);
}

int write_data_to_pc(int fd, unsigned char *buffer, unsigned long len)
{
    //int bytesWritten = 0;
    //int bytesToWrite = len;
/*TODO Do not check MTU size here, assume MTU size is 1500 */

    if (fd < 0)
        return -1;
#if 0
    // Send len bytes data in buffer
    while (bytesToWrite > 0){
        bytesWritten = write(fd, buffer, bytesToWrite);
        if (bytesWritten < 0){
            if(errno == EINTR || errno == EAGAIN)
                continue;
            else
                return -1;
        }
        bytesToWrite -= bytesWritten;
        buffer += bytesWritten;
    }
#endif
	struct ethhdr *p_ehead;
	struct sockaddr_ll socket_address;
	unsigned char *header, *data;
	int send_result = 0;

	bzero(&packet_send[0], 1536);
	DBG("sizeof(packet_send)=%d\n", sizeof(packet_send));
	header = &packet_send[0];
	data = &packet_send[14];
	p_ehead = (struct ethhdr *)&packet_send[0];

	os_memcpy(data, buffer, len);
	os_memcpy(p_ehead->h_dest,   broadcast_addr, 6);
	os_memcpy(p_ehead->h_source, my_eth_addr, 6);
	p_ehead->h_proto = htons(eth_protocol);

	if ((len + ETH_HDR_SIZE) < 60 )
	{
		len = 60 - ETH_HDR_SIZE;
	}
	else if (len > 1514 )
	{
		ERR("response ethernet length is too long\n");
		return -1;
	}

	socket_address.sll_family = PF_PACKET;
	//socket_address.sll_protocol = htons(ETH_P_RACFG);
	socket_address.sll_protocol = eth_protocol;//ETH_P_RACFG;
	socket_address.sll_ifindex = if_index;
	//socket_address.sll_pkttype = (bUnicast == FALSE) ? PACKET_BROADCAST : PACKET_OTHERHOST;
	socket_address.sll_pkttype = PACKET_BROADCAST;
	//socket_address.sll_hatype = ARPHRD_ETHER;
	socket_address.sll_hatype = 1;

	socket_address.sll_halen = 6;/*ETH_ADDR_SIZE*/;

	bzero(&socket_address.sll_addr[0], 8);

//	if (bUnicast == FALSE)
//	{
		/* respond to QA by broadcast frame */
		os_memcpy(&socket_address.sll_addr[0], broadcast_addr, 6);
//	}
//	else
//	{
		/* respond to QA by unicast frame */
//		os_memcpy(&socket_address.sll_addr[0], p_ehead->h_dest, 6);
//	}

   	send_result = sendto(fd, packet_send, len + ETH_HDR_SIZE, 0, (struct sockaddr *)&socket_address, sizeof(socket_address));

	DBG("response send bytes = %d\n", send_result);


    return 0;
}

int read_data_from_pc(int fd, unsigned char *buffer, unsigned long len)
{
    int bytesRead = 0;
    int bytesToRead = len;

    int ret = 0;
    //struct timeval tv;
    fd_set readfd;

    //unsigned short rcv_protocol;
    struct ethhdr		*p_ehead;

    //tv.tv_sec = 5;  //SECOND
    //tv.tv_usec = 0;   //USECOND
    FD_ZERO(&readfd);

    if (fd < 0)
        return -1;

    if (!eth_packet_recvd){
        eth_packet_len = 0;

        FD_ZERO(&readfd);
        FD_SET(fd, &readfd);

        //count = select(sock+1,&readfds,NULL,NULL,&tv);
        ret = select(fd + 1, &readfd, NULL, NULL, NULL);

        if (ret < 0)
        {
        	ERR("socket select error\n");
        	perror("select failed():");
        	return -1;
        }
        else if (ret == 0)
        {
        	return -1;
        }
        else
        {
            /* Data is available now. */
            if (FD_ISSET(fd, &readfd))
            {
                if ((bytesRead  = recvfrom(fd, packet, sizeof(packet), 0, NULL, NULL)) > 0){
//                    os_memcpy(&rcv_protocol, packet + 12, 2);

                    p_ehead = (struct ethhdr *) &packet[0];
                    /* recv the protocol we are waiting */
                    //if (rcv_protocol == ntohs(ETH_P_RACFG)){
                    if ((p_ehead->h_proto == htons(eth_protocol)) &&
                        ((strncmp(my_eth_addr, (char *)p_ehead->h_dest, 6) == 0) ||
                        (strncmp(broadcast_addr, (char *)p_ehead->h_dest, 6) == 0))){

//                        DBG("rcv_protocol=[%x], ntohs(ETH_P_RACFG)=[%x]\n", rcv_protocol, ntohs(ETH_P_RACFG));
                        DBG("rcv_protocol=[%x], ntohs(ETH_P_RACFG)=[%x]\n", p_ehead->h_proto, eth_protocol);
                        DBG("Receive packet[%d] from PC.\n", bytesRead);
                        //NetReceive(eth_buffer, n);
                    } else {
			DBG("Receive the packet we do not care\n");
                    }
                    eth_packet_recvd = 1;
                    eth_packet_len = bytesRead;
	            os_memcpy(buffer, packet + ETH_HDR_SIZE, bytesToRead);
                    buffer_read = bytesToRead;
                }
                else if (bytesRead == 0){
                    return -1; // read ethernet socket timeout 5000ms
                }
                //else if ((bytesRead == -1) && (errno == EINTR)){
                //    continue;
                //}
                else{
                    return -1;
                }
            }
        }
	//TODO
    } else {
        /*|---------------|-----------------|----------------|
          |  buffer_read  |   bytesToRead   |
          |                 eth_packet_len                   |*/
        if(buffer_read + bytesToRead <= eth_packet_len) {
            os_memcpy(buffer, packet + ETH_HDR_SIZE + buffer_read, bytesToRead);
            buffer_read += bytesToRead;
        } else {
            ERR("Read too much data from received ethernet packet.\n");
        }
    }
    return 0;
}
#endif

/*-------------------------------*/
/*          Common Part          */
/*-------------------------------*/
static BOOL RELAYER_write(
    int  fd,
    unsigned char *peer_buf,
    int  peer_len)
{

    if (peer_buf == NULL){
        ERR("NULL write buffer\n");
        return FALSE;
    }

    if ((peer_buf[0] != 0x04) && (peer_buf[0] != 0x02) && (peer_buf[0] != 0x03)){
        ERR("Invalid packet type 0x%02x to PC\n", peer_buf[0]);
        return FALSE;
    }

    if (write_data_to_pc(fd, peer_buf, peer_len) < 0){
        return FALSE;
    }

    return TRUE;
}

static BOOL RELAYER_read(
    int  fd,
    unsigned char *peer_buf,
    int  peer_len,
    int *piResultLen)
{

    UCHAR ucHeader = 0;
    int iLen = 0, pkt_len = 0, count = 0;

    if (peer_buf == NULL){
        ERR("NULL read buffer\n");
        return FALSE;
    }
#if (ETHERNET_SUPPORT)
    eth_packet_recvd = 0;
    buffer_read  = 0;
#endif
LOOP:
    if(read_data_from_pc(fd, &ucHeader, sizeof(ucHeader)) < 0){
        count ++;
        if (count < 3){
	        DBG("read_data_from_pc count = %d\n",count);
            goto LOOP;
        }
        else{
	        DBG("read_data_from_pc iLen = %d\n",iLen);
            *piResultLen = iLen;
            return FALSE;
        }
    }
	DBG("read_data_from_pc out\n");

    peer_buf[0] = ucHeader;
    iLen ++;

    switch (ucHeader)
    {
      case 0x01:
        // HCI command
        if(read_data_from_pc(fd, &peer_buf[1], 3) < 0){
            ERR("Read command header failed\n");
            *piResultLen = iLen;
            return FALSE;
        }

        iLen += 3;
        pkt_len = (int)peer_buf[3];
	DBG("pkt_len in header=%d\n", pkt_len);
        if((iLen + pkt_len) > peer_len){
            ERR("Large packet from PC! packet len %d\n", iLen + pkt_len);
            *piResultLen = iLen;
            return FALSE;
        }

        if(read_data_from_pc(fd, &peer_buf[4], pkt_len) < 0){
            ERR("Read command param failed\n");
            *piResultLen = iLen;
            return FALSE;
        }

        iLen += pkt_len;
        *piResultLen = iLen;
	DBG("total_length(Header+data)=%d\n", iLen);
        break;

      case 0x02:
        // ACL data
        if(read_data_from_pc(fd, &peer_buf[1], 4) < 0){
            ERR("Read ACL header failed\n");
            *piResultLen = iLen;
            return FALSE;
        }

        iLen += 4;
        pkt_len = (((int)peer_buf[4]) << 8);
        pkt_len += peer_buf[3];//little endian
        if((iLen + pkt_len) > peer_len){
            ERR("Large packet from PC! packet len %d\n", iLen + pkt_len);
            *piResultLen = iLen;
            return FALSE;
        }

        if(read_data_from_pc(fd, &peer_buf[5], pkt_len) < 0){
            ERR("Read ACL data failed\n");
            *piResultLen = iLen;
            return FALSE;
        }

        iLen += pkt_len;
        *piResultLen = iLen;
        break;

      case 0x03:
        // SCO data
        if(read_data_from_pc(fd, &peer_buf[1], 3) < 0){
            ERR("Read SCO header failed\n");
            *piResultLen = iLen;
            return FALSE;
        }

        iLen += 3;
        pkt_len = (int)peer_buf[3];
        if((iLen + pkt_len) > peer_len){
            ERR("Large packet from PC! packet len %d\n", iLen + pkt_len);
            *piResultLen = iLen;
            return FALSE;
        }

        if(read_data_from_pc(fd, &peer_buf[4], pkt_len) < 0){
            ERR("Read SCO data failed\n");
            *piResultLen = iLen;
            return FALSE;
        }

        iLen += pkt_len;
        *piResultLen = iLen;
        break;

      default:
        // Filter PC garbage data
        ERR("Invalid packet type %02x from PC\n", ucHeader);
        *piResultLen = 0;
        return FALSE;
    }

    return TRUE;
}


static void thread_exit(int signo)
{
    pthread_t tid = pthread_self();
    DBG("Thread %lu exits\n", tid);
    pthread_exit(0);
}

static void *bt_tx_monitor(void *ptr)
{
    UCHAR ucTxBuf[2048];
    int iPktLen;
    int ret = 0;
    unsigned char power_on_command[] = { 0x01, 0x6F, 0xFC, 0x06, 0x01, 0x06, 0x02, 0x00, 0x00, 0x01 };

    DBG("Thread %lu starts\n", txThread);

    while (1){
        memset(ucTxBuf, 0, sizeof(ucTxBuf));
        iPktLen = 0;

        // Receive HCI packet from PC
#if (UART_SUPPORT)
        ret = RELAYER_read(serial_fd, ucTxBuf, sizeof(ucTxBuf), &iPktLen);
#endif
#if (ETHERNET_SUPPORT)
        ret = RELAYER_read(sock, ucTxBuf, sizeof(ucTxBuf), &iPktLen);
#endif
        if(ret)
        {
            DBG("Receive packet from PC\n");
            dump_hex(ucTxBuf, iPktLen);
            // Send the packet to BT Controller
            //if(EM_BT_write(ucTxBuf, iPktLen)){
            if(mtk_bt_write(bt_fd, ucTxBuf, iPktLen)){
                if (0 == memcmp(ucTxBuf, power_on_command, 10)) {
                    bt_power_on_cmd = TRUE;
                }
                sched_yield();
                continue;
            }
            else{
                ERR("Send packet to BT Controller failed\n");
                pthread_kill(rxThread, SIGRTMIN);
                break;
            }
        }
        else{
            if (iPktLen == 0){
                continue;
            }
            else{
                ERR("Receive packet from PC failed\n");
                pthread_kill(rxThread, SIGRTMIN);
                break;
            }
        }
    }
    return 0;
}

static void *bt_rx_monitor(void *ptr)
{
    UCHAR ucRxBuf[2048];
    int iPktLen = 0;
    int ret = 0;
    BT_REQ bt_req;
    BT_RESULT bt_info;
    unsigned char power_on_event[] = { 0x04, 0xE4, 0x05, 0x02, 0x06, 0x01, 0x00 };


    DBG("Thread %lu starts\n", rxThread);

    while (1){
        memset(ucRxBuf, 0, sizeof(ucRxBuf));

        // Receive HCI packet from BT Controller
        //if(EM_BT_read(ucRxBuf, sizeof(ucRxBuf), &iPktLen))
        iPktLen = mtk_bt_read(bt_fd, ucRxBuf, sizeof(ucRxBuf));
	if (iPktLen)
        {
            DBG("Send packet to PC\n");
            dump_hex(ucRxBuf, iPktLen);

            // Send the packet to PC
#if (UART_SUPPORT)
            ret = RELAYER_write(serial_fd, ucRxBuf, iPktLen);
#endif
#if (ETHERNET_SUPPORT)
            ret = RELAYER_write(sock, ucRxBuf, iPktLen);
#endif
            //handle power on event, send set addr, radio setting, tx power command
            if ((0 == memcmp(ucRxBuf, power_on_event, 7)) &&
                (bt_power_on_cmd == TRUE)) {
                bt_power_on_cmd = FALSE;
                bt_req.op = BT_DRV_OP_FW_CFG;
                bt_req.param.fd = bt_fd;
                mtk_bt_op(bt_req, &bt_info);
            }
            if(ret){
                sched_yield();
                continue;
            }
            else{
                ERR("Send packet to PC failed\n");
                pthread_kill(txThread, SIGRTMIN);
                break;
            }
        }
        else{
            if (iPktLen == 0){
                continue;
            }
            else{
                ERR("Receive packet from BT Controller failed\n");
                pthread_kill(txThread, SIGRTMIN);
                break;
            }
        }
    }
    return 0;
}



BOOL RELAYER_start(int serial_port, int serial_speed)
{
    TRC();

    //if (EM_BT_init()){
    bt_fd = mtk_bt_enable(0, NULL);
    if (bt_fd > 0){
        DBG("BT device power on success\n");
    }
    else{
        ERR("BT device power on failed\n");
        return FALSE;
    }
#if (UART_SUPPORT)
    serial_fd = init_serial(SERIAL_PORT_NUM, SERIAL_BAUDRATE);
    if (serial_fd < 0){
        ERR("Initialize serial port to PC failed\n");
        //EM_BT_deinit();
	mtk_bt_disable(bt_fd);
        return FALSE;
    }
#endif
#if (ETHERNET_SUPPORT)
    sock = OpenRaCfgSocket();
    if ( sock < 0)
    {
	ERR("[%s]Socket initial failed\n", __FUNCTION__);
        return FALSE;
    }
#endif
    signal(SIGRTMIN, thread_exit);
    /* Create Tx monitor thread */
    pthread_create(&txThread, NULL, bt_tx_monitor, (void*)NULL);
    /* Create RX monitor thread */
    pthread_create(&rxThread, NULL, bt_rx_monitor, (void*)NULL);

    DBG("BT Relayer mode start\n");

    return TRUE;
}

void RELAYER_exit()
{
    TRC();

    /* Wait until thread exit */
    pthread_kill(txThread, SIGRTMIN);
    pthread_join(txThread, NULL);
    pthread_kill(rxThread, SIGRTMIN);
    pthread_join(rxThread, NULL);

    close(serial_fd);
    serial_fd = -1;

    //EM_BT_deinit();
    mtk_bt_disable(bt_fd);
}

