int str_to_mac (unsigned char *mac, char *str);
int str_to_ip (unsigned int *ip, char *str);
int str_to_ipv6 ( unsigned int * ipv6, char *str, unsigned int byte);
