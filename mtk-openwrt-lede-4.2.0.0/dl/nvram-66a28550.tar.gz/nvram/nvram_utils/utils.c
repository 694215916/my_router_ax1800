#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>
#include <linux/wireless.h>
#include "utils.h"

#if defined (WSC_SUPPORT)
void getCurrentWscProfile(char *interface, WSC_CONFIGURED_VALUE *data, int len)
{
	int socket_id;
	struct iwreq wrq;

	if ((socket_id = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		DBG_MSG("socket open Fail !");
	strcpy((char *)data, "get_wsc_profile");
	strcpy(wrq.ifr_name, interface);
	wrq.u.data.length = len;
	wrq.u.data.pointer = (caddr_t) data;
	wrq.u.data.flags = 0;
	if (ioctl(socket_id, RTPRIV_IOCTL_WSC_PROFILE, &wrq) < 0) {
		DBG_MSG("ioctl -> RTPRIV_IOCTL_WSC_PROFILE Fail !");
	}
	close(socket_id);
}

int getWscStatus(char *interface)
{
	int socket_id;
	struct iwreq wrq;
	int data = 0;
	socket_id = socket(AF_INET, SOCK_DGRAM, 0);
	strcpy(wrq.ifr_name, interface);
	wrq.u.data.length = sizeof(data);
	wrq.u.data.pointer = (caddr_t) &data;
	wrq.u.data.flags = RT_OID_WSC_QUERY_STATUS;
	if( ioctl(socket_id, RT_PRIV_IOCTL, &wrq) == -1)
		DBG_MSG("ioctl error");
	close(socket_id);
	//DBG_MSG("[DBG]data=%d", data); //Landen

	return data;
}

int getWscProfile(char *interface, WSC_PROFILE *wsc_profile)
{
	int socket_id;
	struct iwreq wrq;

	socket_id = socket(AF_INET, SOCK_DGRAM, 0);
	strcpy(wrq.ifr_name, interface);
	wrq.u.data.length = sizeof(WSC_PROFILE);
	wrq.u.data.pointer = (caddr_t) wsc_profile;
	wrq.u.data.flags = RT_OID_802_11_WSC_QUERY_PROFILE;
	if( ioctl(socket_id, RT_PRIV_IOCTL, &wrq) == -1){
		DBG_MSG("ioctl error\n");
		return -1;
	}
	close(socket_id);

	return 0;
}
#endif

void set_nth_value_flash(int nvram, int index, char *flash_key, const char *value)
{
	char *result;
	char *tmp = (char *) nvram_bufget(nvram, flash_key);
	if(!tmp)
		tmp = "";
	result = set_nth_value(index, tmp, value);
	nvram_bufset(nvram, flash_key, result);
}

char *racat(char *s, int i)
{
	static char str[32];
	snprintf(str, 32, "%s%1d", s, i);
	return str;
}

int get_nth_value(int index, const char *value, char delimit, char *result, int len)
{
	int i=0, result_len=0;
	const char *begin, *end;

	if(!value || !result || !len)
		return -1;

	begin = value;
	end = strchr(begin, delimit);

	while(i<index && end){
		begin = end+1;
		end = strchr(begin, delimit);
		i++;
	}

	//no delimit
	if(!end){
		if (i == index){
			end = begin + strlen(begin);
			result_len = (len-1) < (end-begin) ? (len-1) : (end-begin);
		}else
			return -1;
	} else {
		result_len = (len-1) < (end-begin)? (len-1) : (end-begin);
	}

	memcpy(result, begin, result_len );
	*(result+ result_len ) = '\0';

	return 0;
}

int get_nth_number(int index, const char *value, char delimit, int base)
{
	char str[64] = {0};
	//int num = 0;

	//DBG_MSG("index=%d, input value=%s, delimit=%c\n", index, value, delimit);
	if(get_nth_value(index, value, delimit, str, sizeof(str)) != 0)
		return 0;

	if((str != NULL) && (strlen(str) > 0)){
		//DBG_MSG("str=%s\n", str);
		return (int)strtol(str, NULL, base);
	}

	return 0;
}

char *set_nth_value(int index, char *old_values, const char *new_value)
{
	int i;
	char *p, *q;
	//static char ret[2048];
	//char buf[8][256];
	static char ret[MBSSID_MAX_NUM*256];
	char buf[MBSSID_MAX_NUM][256];

	memset(ret, 0, sizeof(ret));
	//for (i = 0; i < 8; i++)
	for (i = 0; i < MBSSID_MAX_NUM; i++)
		memset(buf[i], 0, 256);

	//copy original values
	for ( i = 0, p = old_values, q = strchr(p, ';')  ;
			//i < 8 && q != NULL;
			i < MBSSID_MAX_NUM && q != NULL;
			i++, p = q + 1, q = strchr(p, ';')         )
	{
		strncpy(buf[i], p, q - p);
	}
	//if (i >=8) i=7;
	if (i >= MBSSID_MAX_NUM) i = MBSSID_MAX_NUM - 1;
	strcpy(buf[i], p); //the last one

	//replace buf[index] with new_value
	strncpy(buf[index], new_value, 256);

	//calculate maximum index
	index = (i > index)? i : index;

	//concatenate into a single string delimited by semicolons
	strcat(ret, buf[0]);
	for (i = 1; i <= index; i++) {
		strncat(ret, ";", 2);
		strncat(&ret[0], buf[i], 256);
		//snprintf(ret, sizeof(ret), "%s%s", ret,  buf[i]);
	}

	return ret;
}

char *set_nth_value_default(int index, char *old_values, char *new_value, const char *def_value)
{
	int i;
	char *p, *q;
	//static char ret[2048];
	//char buf[8][256];
	static char ret[MBSSID_MAX_NUM*256];
	char buf[MBSSID_MAX_NUM][256];

	memset(ret, 0, sizeof(ret));
	//for (i = 0; i < 8; i++)
	for (i = 0; i < MBSSID_MAX_NUM; i++)
		memset(buf[i], 0, 256);

	//copy original values
	for ( i = 0, p = old_values, q = strchr(p, ';')  ;
			//i < 8 && q != NULL;
			i < MBSSID_MAX_NUM && q != NULL;
			i++, p = q + 1, q = strchr(p, ';')         )
	{
		strncpy(buf[i], p, q - p);
	}
	//if (i >=8) i=7;
	if (i >= MBSSID_MAX_NUM) i = MBSSID_MAX_NUM - 1;
	strcpy(buf[i], p); //the last one

	//replace buf[index] with new_value
	strncpy(buf[index], new_value, 256);

	//calculate maximum index
	index = (i > index)? i : index;

	//concatenate into a single string delimited by semicolons
	strcat(ret, buf[0]);
	for (i = 1; i <= index; i++) {
		strncat(ret, ";", 2);
		//strncat(&ret[0], buf[i], 256);
		if((strlen(buf[i]) == 0) && (def_value != NULL))
			snprintf(ret, sizeof(ret), "%s%s", ret, def_value);
		else
		snprintf(ret, sizeof(ret), "%s%s", ret,  buf[i]);
	}

	return ret;
}

void set_nth_value_default_flash(int nvram, int index, char *flash_key, char *value, const char *def_value)
{
	char *result;
	char *tmp = (char *) nvram_bufget(nvram, flash_key);
	if(!tmp)
		tmp = "";
	result = set_nth_value_default(index, tmp, value, def_value);
	nvram_bufset(nvram, flash_key, result);
}

int OidQueryInformation(unsigned long OidQueryCode, int socket_id, char *DeviceName, void *ptr, unsigned long PtrLength)
{
	struct iwreq wrq;

	strcpy(wrq.ifr_name, DeviceName);
	wrq.u.data.length = PtrLength;
	wrq.u.data.pointer = (caddr_t) ptr;
	wrq.u.data.flags = OidQueryCode;

	return (ioctl(socket_id, RT_PRIV_IOCTL, &wrq));
}

int OidSetInformation(unsigned long OidQueryCode, int socket_id, char *DeviceName, void *ptr, unsigned long PtrLength)
{
	struct iwreq wrq;

	strcpy(wrq.ifr_name, DeviceName);
	wrq.u.data.length = PtrLength;
	wrq.u.data.pointer = (caddr_t) ptr;
	wrq.u.data.flags = OidQueryCode | OID_GET_SET_TOGGLE;

	return (ioctl(socket_id, RT_PRIV_IOCTL, &wrq));
}

int port_secured(char *ifname)
{
	int s;
	unsigned int ConnectStatus = 0;
	
	if (ifname == NULL)
		return -1;

	s = socket(AF_INET, SOCK_DGRAM, 0);
	if (OidQueryInformation(OID_GEN_MEDIA_CONNECT_STATUS, s, ifname, &ConnectStatus, sizeof(ConnectStatus)) < 0) {
		DBG_MSG("Query OID_GEN_MEDIA_CONNECT_STATUS error!");
		close(s);
		return -1;
	}
	close(s);

	if (ConnectStatus == 1)
		return 1;
	else
		return 0;
}
